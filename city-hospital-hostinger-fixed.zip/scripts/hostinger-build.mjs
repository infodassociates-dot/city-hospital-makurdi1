import {fileURLToPath} from 'node:url';
process.env.DEPLOY_TARGET='hostinger';
process.env.NEXT_PUBLIC_SITE_URL='https://cityhospitalmakurdi.com';
process.env.NODE_ENV='production';
const cli=new URL('../node_modules/vinext/dist/cli.js',import.meta.url);
process.argv=[process.execPath,fileURLToPath(cli),'build'];
await import(cli.href);
