export const specialtyPhotos:Record<string,{alt:string;caption:string}> = {
  "general-practice": {"alt":"Illustrative Black African general practitioner discussing care with an adult woman in a bright consultation room","caption":"General practice offers a starting point for everyday health concerns."},
  "internal-medicine": {
    "alt": "Illustrative Nigerian physician listening to an adult patient during an internal medicine consultation",
    "caption": "Internal medicine brings your symptoms, medical history and treatment together."
  },
  "obstetrics-gynaecology": {
    "alt": "Illustrative obstetrician explaining pregnancy care to an expectant mother and her partner",
    "caption": "Support for pregnancy and women’s reproductive health begins with a conversation."
  },
  "general-surgery": {
    "alt": "Illustrative surgeon using an anatomical model to explain care options to a patient",
    "caption": "A surgical consultation helps you understand assessment, options and preparation."
  },
  "haematology": {
    "alt": "Illustrative laboratory scientist examining a prepared blood slide using a microscope",
    "caption": "Haematology focuses on blood cells and blood-related conditions."
  },
  "chemical-pathology": {
    "alt": "Illustrative biochemistry scientist using a micropipette to prepare a sample for chemical analysis",
    "caption": "Chemical pathology studies body-fluid chemistry to support clinical assessment."
  }
};
