export const contact = {
  phones: [
    { label: '0813 355 4487', international: '+234 813 355 4487', href: 'tel:+2348133554487' },
    { label: '0912 635 2917', international: '+234 912 635 2917', href: 'tel:+2349126352917' },
  ],
  whatsapp: { label: 'WhatsApp', number: '0813 355 4487', href: 'https://wa.me/2348133554487?text=Hello%20City%20Hospital%20Makurdi%2C%20I%20would%20like%20information%20about%20appointment%20availability.' },
  email: 'admin@cityhospitalmakurdi.com',
  streetAddress: 'Emmanuel Mande Close, off Kashim Ibrahim Road, Old GRA',
  address: 'Emmanuel Mande Close, off Kashim Ibrahim Road, Old GRA, Makurdi, Benue State, Nigeria',
};
// Add the hospital's approved profile URLs here when available.
export const socialProfiles: { name: string; url: string | null }[] = [
  { name: 'Facebook', url: 'https://www.facebook.com/cityhospitalmakurdi' },
  { name: 'Instagram', url: 'https://www.instagram.com/cityhospitalmakurdi25/' },
  { name: 'LinkedIn', url: 'https://www.linkedin.com/company/city-hospital-makurdi/' },
  { name: 'TikTok', url: 'https://www.tiktok.com/@cityhospitalmakurdi' },
];
