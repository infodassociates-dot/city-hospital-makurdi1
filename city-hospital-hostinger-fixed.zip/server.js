// Hostinger entry point when paths are resolved from the project root.
await import('./dist/standalone/server.js');
