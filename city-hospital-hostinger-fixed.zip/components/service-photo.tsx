const descriptions: Record<string, string> = {
  'general-medical-consultations': 'A Nigerian doctor discussing care with a mother and daughter',
  'outpatient-care': 'A doctor consulting an adult patient in an outpatient clinic',
  'inpatient-care': 'A nurse supporting a patient in a private hospital ward',
  'maternity-care': 'A midwife discussing antenatal care with an expectant mother and her partner',
  paediatrics: 'A clinician examining a young boy with his father nearby',
  'emergency-care': 'A nurse assessing a patient in a hospital triage area',
  'surgical-services': 'Surgical clinicians preparing equipment in an operating theatre',
  'ultrasound-scanning': 'A sonographer performing an abdominal ultrasound scan',
  'laboratory-services': 'A laboratory scientist working at a clinical laboratory bench',
  'pharmacy-services': 'A pharmacist discussing medicines with a patient',
  'gynaecology-services': 'A female clinician discussing care privately with an adult woman',
  'preventive-health': 'A nurse checking an adult patient’s blood pressure',
  'tuberculosis-care': 'A clinician and patient wearing masks during a consultation',
  'hiv-care': 'A clinician discussing follow-up care privately with an adult patient',
  'services-overview': 'Two Nigerian clinicians discussing care in a hospital corridor',
  'patient-information': 'A patient preparing documents for a hospital visit at reception',
  contact: 'A receptionist welcoming a couple to a hospital',
  partnerships: 'Clinicians planning follow-up care with a patient',
};

export function ServicePhoto({slug, page}: {slug?: string; page?: string}) {
  const image = slug || page || 'services-overview';
  return <figure className={slug ? 'service-detail-photo' : 'service-directory-photo'}>
    <img src={`/images/${image}.webp`} alt={`Illustrative scene: ${descriptions[image]}`} loading="lazy" width={1536} height={1024}/>
    <figcaption>Illustrative healthcare scene</figcaption>
  </figure>;
}
