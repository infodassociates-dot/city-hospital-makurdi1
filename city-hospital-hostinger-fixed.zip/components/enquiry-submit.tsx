'use client';
import {useEffect,useState} from 'react';
async function readResponse(response:Response){const data=await response.json() as Record<string,unknown>;return {token:typeof data.token==='string'?data.token:'',message:typeof data.message==='string'?data.message:'',reference:typeof data.reference==='string'?data.reference:undefined}}
export function useEnquiry(kind:'patient'|'partnership'|'appointment'){
 const [token,setToken]=useState('');const [busy,setBusy]=useState(false);const [result,setResult]=useState<{ok:boolean;message:string;reference?:string}|null>(null);
 useEffect(()=>{let active=true;fetch('/api/enquiries',{cache:'no-store'}).then(readResponse).then(data=>{if(active&&data.token)setToken(data.token)}).catch(()=>{});return()=>{active=false}},[]);
 async function submit(event:React.FormEvent<HTMLFormElement>){event.preventDefault();if(busy)return;const data=new FormData(event.currentTarget);setBusy(true);setResult(null);
 try{if(!token){const check=await fetch('/api/enquiries',{cache:'no-store'});const response=await readResponse(check);if(!check.ok)throw new Error(response.message||'Online enquiries are temporarily unavailable. Please call or email the hospital.');setToken(response.token);throw new Error('The form is ready. Please wait two seconds, then submit again.');}
 const fields=Object.fromEntries(Array.from(data.entries()).filter(([key])=>!['website','acknowledgement'].includes(key)));
 const response=await fetch('/api/enquiries',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({kind,token,website:data.get('website')||'',acknowledgement:data.get('acknowledgement')==='on',fields})});const body=await readResponse(response);setResult({ok:response.ok,message:body.message||'Delivery could not be confirmed. Please contact the hospital.',reference:response.ok?body.reference:undefined});
 setToken('');fetch('/api/enquiries',{cache:'no-store'}).then(readResponse).then(d=>setToken(d.token||'')).catch(()=>{});
 }catch(error){setResult({ok:false,message:error instanceof Error?error.message:'Delivery could not be confirmed. Please call or email the hospital.'})}finally{setBusy(false)}
 }
 return {submit,busy,result};
}
export function EnquiryFeedback({result}:{result:{ok:boolean;message:string;reference?:string}|null}){return result?<div className={result.ok?'enquiry-result':'enquiry-result enquiry-error'} role={result.ok?'status':'alert'}><p>{result.message}</p>{result.reference&&<p>Enquiry reference: {result.reference}</p>}</div>:null}
export function EnquiryHoneypot(){return <div className="enquiry-honeypot" aria-hidden="true"><label>Leave this field empty<input name="website" tabIndex={-1} autoComplete="off"/></label></div>}
