'use client';
import {useEffect} from 'react';
const allowed=new Set(['home_hero','home_patient','home_partnership','home_network','patient_submit_attempt','partnership_submit_attempt','patient_email_open','partnership_email_open']);
// Integration hook only: no collector, persistence, form values, URL or personal data.
export function HmoMeasurement(){useEffect(()=>{const click=(event:MouseEvent)=>{const target=event.target instanceof Element?event.target.closest<HTMLElement>('[data-hmo-event]'):null;const action=target?.dataset.hmoEvent;if(action&&allowed.has(action))window.dispatchEvent(new CustomEvent('hospital:hmo-action',{detail:{action}}));};document.addEventListener('click',click);return()=>document.removeEventListener('click',click);},[]);return null}
