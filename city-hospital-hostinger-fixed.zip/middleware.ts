import {NextResponse} from 'next/server';
import type {NextRequest} from 'next/server';
export function middleware(request:NextRequest){
 if(process.env.ENFORCE_CANONICAL!=='true')return NextResponse.next();
 const host=(request.headers.get('host')||'').toLowerCase().split(':')[0];
 if(!['cityhospitalmakurdi.com','www.cityhospitalmakurdi.com'].includes(host))return new NextResponse('Unrecognised website host',{status:421});
 const protocol=process.env.TRUST_PROXY==='true'?request.headers.get('x-forwarded-proto')?.split(',')[0].trim():request.nextUrl.protocol.replace(':','');
 if(host==='www.cityhospitalmakurdi.com'||protocol!=='https')return NextResponse.redirect(new URL(request.nextUrl.pathname+request.nextUrl.search,'https://cityhospitalmakurdi.com'),308);
 return NextResponse.next();
}
