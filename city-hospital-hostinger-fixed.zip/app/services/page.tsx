import Link from 'next/link';
import type {Metadata} from 'next';
import {ServiceDirectory} from '@/components/hospital';
import {PageHeading} from '@/components/page-heading';
import {ServicePhoto} from '@/components/service-photo';
export const metadata:Metadata={title:'Medical Services in Makurdi',description:'Explore 14 City Hospital Makurdi services, including consultations, maternity, paediatrics, ultrasound, laboratory, surgery, HIV and TB care.',alternates:{canonical:'/services'}};
export default function Services(){return <><PageHeading title="Medical care for every stage of life." intro="Find the service that fits your needs. We provide medical care for individuals and families in Makurdi, surrounding communities and Benue State."/><section className="section wrap"><ServicePhoto/><p className="specialist-directory-link">Looking for specialist care? <Link className="text-link" href="/specialist-services">Explore our six key areas of medical practice</Link>.</p><ServiceDirectory/><p className="hospital-note">Availability, appointment arrangements and fees should be confirmed with the hospital. For an emergency, seek urgent in-person medical attention; do not wait for an online response.</p></section></>}
