import {createHmac,randomBytes,timingSafeEqual,createHash} from 'node:crypto';
import nodemailer from 'nodemailer';
export const runtime='nodejs';
const MAX_BYTES=12000;const TOKEN_TTL=30*60*1000;
const consumed=new Map<string,number>();const limits=new Map<string,{count:number;expires:number}>();
const headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
function reply(status:number,message:string,extra:Record<string,string>={}){return Response.json({message,...extra},{status,headers})}
function config(){const e=process.env;return e.SMTP_HOST&&e.SMTP_USER&&e.SMTP_PASSWORD&&e.ENQUIRY_FROM&&e.ENQUIRY_TO&&e.ENQUIRY_TOKEN_SECRET&&e.ENQUIRY_TOKEN_SECRET.length>=32&&['465','587'].includes(e.SMTP_PORT||'')?e:null}
function originAllowed(req:Request){const allowed=process.env.NEXT_PUBLIC_SITE_URL||'http://127.0.0.1:5173';const origin=req.headers.get('origin');return origin===allowed||(req.method==='GET'&&!origin&&new URL(req.headers.get('referer')||req.url).origin===allowed)}
function signature(value:string,secret:string){return createHmac('sha256',secret).update(value).digest('hex')}
function limited(key:string,max:number){const now=Date.now();for(const [k,v]of limits)if(v.expires<=now)limits.delete(k);const item=limits.get(key)||{count:0,expires:now+10*60*1000};item.count++;limits.set(key,item);return item.count>max}
function validToken(token:string,secret:string){const parts=token.split('.');if(parts.length!==3)return false;const value=parts.slice(0,2).join('.');const expected=signature(value,secret);if(!/^[a-f0-9]{64}$/.test(parts[2])||!timingSafeEqual(Buffer.from(expected),Buffer.from(parts[2])))return false;const age=Date.now()-Number(parts[0]);return age>=2000&&age<TOKEN_TTL}
const email=/^[^\s@<>\r\n]+@[^\s@<>\r\n]+\.[^\s@<>\r\n]+$/;
const phone=/^[+0-9 ()-]{7,25}$/;
const orgTypes=['Private employer','Primary or secondary school','College or university','Public ministry or agency','Uniformed service','HMO or scheme administrator','NGO','Other organisation'];
const populations=['1–25','26–100','101–500','501–1,000','Over 1,000','To be discussed'];
const enquiryTypes=['Provider network','Employee healthcare','Institutional healthcare','Direct corporate agreement','Referral arrangement','Procurement or tender discussion','Other'];
const services=['','general-practice','internal-medicine','obstetrics-gynaecology','general-surgery','haematology','chemical-pathology'];
export async function GET(req:Request){if(!originAllowed(req))return reply(403,'Please open the enquiry form on the hospital website.');const env=config();if(!env)return reply(503,'Online enquiries are temporarily unavailable. Please call or email the hospital.');if(limited('tokens',120))return reply(429,'Please try again later or call the hospital.');const value=Date.now()+'.'+randomBytes(18).toString('hex');return Response.json({token:value+'.'+signature(value,env.ENQUIRY_TOKEN_SECRET!)},{headers})}
export async function POST(req:Request){
 if(!originAllowed(req))return reply(403,'Please submit from the hospital website.');
 if(!req.headers.get('content-type')?.startsWith('application/json'))return reply(415,'Please use the website enquiry form.');
 if(Number(req.headers.get('content-length')||0)>MAX_BYTES)return reply(413,'The enquiry is too long.');
 const reader=req.body?.getReader();if(!reader)return reply(400,'Please complete the enquiry form.');let length=0;const chunks:Uint8Array[]=[];
 while(true){const part=await reader.read();if(part.done)break;length+=part.value.byteLength;if(length>MAX_BYTES){await reader.cancel();return reply(413,'The enquiry is too long.')}chunks.push(part.value)}
 let data:Record<string,unknown>;try{data=JSON.parse(Buffer.concat(chunks).toString('utf8'));if(!data||Array.isArray(data)||typeof data!=='object')throw new Error()}catch{return reply(400,'The enquiry could not be read. Please try again.')}
 const env=config();if(!env)return reply(503,'Online enquiries are temporarily unavailable. Please call or email the hospital.');
 if(data.website||typeof data.token!=='string'||!validToken(data.token,env.ENQUIRY_TOKEN_SECRET!))return reply(400,'Please wait a moment and try again, or refresh the page if the form has expired.');
 const now=Date.now();for(const [k,v]of consumed)if(v<now)consumed.delete(k);
 const tokenKey=createHash('sha256').update(data.token).digest('hex');if(consumed.has(tokenKey))return reply(409,'This request has already been processed. Please check the previous response before submitting again.');
 const kind=data.kind;if(!['patient','partnership','appointment'].includes(String(kind)))return reply(400,'Choose a valid enquiry type.');
 const f=data.fields;if(!f||typeof f!=='object'||Array.isArray(f))return reply(400,'Complete the required fields.');
 const fields=f as Record<string,unknown>;const allowed=kind==='patient'?['Name','Preferred contact method','Email','Telephone','HMO','Plan']:kind==='partnership'?['Organisation','Organisation type','Name','Role','Preferred contact method','Business email','Telephone','Location','Population band','HMO arrangement','Existing HMO','Enquiry type','Requirements']:['Name','Preferred contact method','Email','Telephone','Service','Message'];
 if(Object.keys(fields).some(k=>!allowed.includes(k)))return reply(400,'The form contains an unsupported field.');
 const cleaned:Record<string,string>={};for(const key of allowed){const value=fields[key];if(value===undefined)continue;if(typeof value!=='string'||value.length>(['Requirements','Message'].includes(key)?600:120)||/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value))return reply(400,'Check the field lengths and remove unsupported characters.');cleaned[key]=value.trim();}
 const required=['Name','Preferred contact method',...(kind==='patient'?['HMO']:kind==='partnership'?['Organisation','Organisation type','Role','Business email','Telephone','Location','Population band','HMO arrangement','Enquiry type']:[])];
 if(data.acknowledgement!==true||required.some(k=>!cleaned[k])||!['Email','Telephone'].includes(cleaned['Preferred contact method']))return reply(400,'Complete the required fields and privacy acknowledgement.');
 const address=cleaned['Business email']||cleaned.Email;const number=cleaned.Telephone;
 if((address&&!email.test(address))||(number&&!phone.test(number))||(cleaned['Preferred contact method']==='Email'&&!address)||(cleaned['Preferred contact method']==='Telephone'&&!number))return reply(400,'Enter a valid email address or telephone number for your preferred contact method.');
 if(kind==='partnership'&&(!orgTypes.includes(cleaned['Organisation type'])||!populations.includes(cleaned['Population band'])||!['Not yet appointed','Currently appointed','Other'].includes(cleaned['HMO arrangement'])||!enquiryTypes.includes(cleaned['Enquiry type'])))return reply(400,'Choose valid organisation and enquiry options.');
 if(kind==='appointment'&&!services.includes(cleaned.Service||''))return reply(400,'Choose a listed service.');
 const recipient=env.ENQUIRY_TO!;if(!email.test(recipient)||!email.test(env.ENQUIRY_FROM!))return reply(503,'Online enquiries are temporarily unavailable. Please call or email the hospital.');
 const contactHash=signature(address||number||'',env.ENQUIRY_TOKEN_SECRET!);if(limited('global-send',40)||limited(contactHash,3))return reply(429,'Too many enquiries have been attempted. Please try again later or call the hospital.');
 consumed.set(tokenKey,now+TOKEN_TTL);
 const reference=randomBytes(8).toString('hex');const subject=kind==='patient'?'HMO access':kind==='partnership'?'Corporate partnership':'Appointment / general contact';
 const transport=nodemailer.createTransport({host:env.SMTP_HOST,port:Number(env.SMTP_PORT),secure:env.SMTP_PORT==='465',requireTLS:true,auth:{user:env.SMTP_USER!,pass:env.SMTP_PASSWORD!},tls:{minVersion:'TLSv1.2',rejectUnauthorized:true},connectionTimeout:12000,greetingTimeout:12000,socketTimeout:20000,logger:false,debug:false});
 try{const result=await transport.sendMail({from:env.ENQUIRY_FROM,to:recipient,...(address?{replyTo:address}:{}),subject:'[City Hospital '+subject+'] '+reference,text:'Website enquiry: '+subject+'\nReference: '+reference+'\n\n'+Object.entries(cleaned).map(([k,v])=>k+': '+v).join('\n')+'\n\nPrivacy acknowledgement: provided.\nThis enquiry does not confirm eligibility, an appointment or a contract.'});if(!result.accepted.map((x:unknown)=>String(x).toLowerCase()).includes(recipient.toLowerCase()))throw new Error('not-accepted');return reply(200,'Your enquiry has been accepted for delivery. The hospital will need to confirm the next steps. This does not confirm eligibility, an appointment or a contract.',{reference})}catch{return reply(502,'Delivery could not be confirmed. Please call or email the hospital before retrying, to avoid duplicate enquiries.')}finally{transport.close()}
}
