import type {MetadataRoute} from 'next';
import {services,origin} from '@/lib/hospital';
import {specialties} from '@/lib/specialties';
export default function sitemap():MetadataRoute.Sitemap{return ['', '/about','/services','/facilities','/patient-information','/contact','/partnerships','/hmo-corporate-healthcare','/specialist-services',...specialties.filter(s=>s.path.startsWith('/specialist-services/')).map(s=>s.path),...services.map(s=>'/services/'+s.slug)].map(path=>({url:origin+path}))}
