import Link from 'next/link';
export default function NotFound(){return <section className="not-found"><p className="eyebrow">PAGE NOT FOUND</p><h1>Let’s find your care.</h1><p>This page is unavailable. Explore our services or return to the homepage.</p><Link className="button" href="/services">Explore medical services</Link></section>}
