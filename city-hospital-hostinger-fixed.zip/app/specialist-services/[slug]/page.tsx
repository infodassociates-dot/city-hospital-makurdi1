import {HmoContextLink} from '@/components/hmo-links';
import type {Metadata} from 'next';
import {notFound} from 'next/navigation';
import {specialties} from '@/lib/specialties';
import {PageHeading} from '@/components/page-heading';
import {SpecialtyContent,SpecialistSchema} from '@/components/specialist-services';
const standalone=specialties.filter(s=>s.path.startsWith('/specialist-services/'));
export function generateStaticParams(){return standalone.map(s=>({slug:s.slug}))}
export async function generateMetadata({params}:{params:Promise<{slug:string}>}):Promise<Metadata>{const {slug}=await params;const s=standalone.find(s=>s.slug===slug);return s?{title:s.title,description:s.description+' Contact City Hospital Makurdi for availability and appointment information.',alternates:{canonical:s.path},openGraph:{title:s.title+' | City Hospital Makurdi',description:s.description,url:s.path,images:[{url:'/brand/city-hospital-logo.png',width:800,height:800,alt:'City Hospital Makurdi logo'}]}}:{title:'Specialty not found'}}
export default async function SpecialtyPage({params}:{params:Promise<{slug:string}>}){const {slug}=await params;const s=standalone.find(s=>s.slug===slug);if(!s)notFound();return <><PageHeading parent={{href:"/specialist-services",label:"Specialist services"}} section={s.name} title={s.title} intro={s.tagline}/><SpecialtyContent specialty={s}/><SpecialistSchema specialty={s}/><section className="wrap"><HmoContextLink/></section></>}
