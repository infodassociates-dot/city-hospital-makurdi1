import type {MetadataRoute} from 'next';
import {origin} from '@/lib/hospital';
export default function robots():MetadataRoute.Robots {return {rules:{userAgent:'*',...(process.env.NEXT_PUBLIC_SITE_URL?{allow:'/'}:{disallow:'/'})},sitemap:origin+'/sitemap.xml'}}
